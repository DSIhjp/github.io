package com.gaore.mobile.haiwai;

import com.gaore.mobile.bean.GRPayParams;
import com.gaore.mobile.bean.GRUserExtraData;
import com.gaore.mobile.callback.GrSDKCallBack;
import com.gaore.mobile.bean.GRToken;
import com.gaore.mobile.GrAPI;
import com.gaore.mobile.base.GrCode;
import com.gaore.mobile.utils.LogUtil;
import com.twmobile.ljsn.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout mIvPay;
    private TextView mTvUserName;

    private Button mBtnLogin;
    private Button mBtnCreateRole;
    private Button mBtnPersonalCenter;
    private Button mBtnLogout;
    private boolean isLogin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gr_home);
        LogUtil.isDebug(true);
        mBtnLogin = (Button) findViewById(R.id.btn_login);
        mIvPay = (LinearLayout) (findViewById(R.id.tv_pay));
        mTvUserName = (TextView) (findViewById(R.id.tv_username));
        mBtnCreateRole = (Button) findViewById(R.id.btn_createRole);
        mBtnPersonalCenter = (Button) findViewById(R.id.btn_personalCenter);
        mBtnLogout = (Button) findViewById(R.id.btn_logout);
        // 初始化
        GrAPI.getInstance().grInitSDK(this, new GrSDKCallBack() {
            @Override
            public void onInitResult(int resultCode) {
                if (resultCode == GrCode.GR_COM_PLATFORM_SUCCESS) {
                    LogUtil.d("init success");
                } else {
                    LogUtil.d( "init fail");
                }
            }

            @Override
            public void onLoginResult(GRToken authResult) {
                LogUtil.d("get token success,  tokenInfo : " + authResult);
                if (authResult.isSuc()) {
                    mTvUserName.setText(authResult.getUsername());
                    isLogin = true;
                    LogUtil.d( "channelID:" + authResult.getChannelID());
                    LogUtil.d( "Token:" + authResult.getToken());
                    LogUtil.d("userid : " + authResult.getUserID());
                } else {
                    LogUtil.d("get Token fail");
                }
            }

            @Override
            public void onLogoutResult(int resultCode) {
                LogUtil.d( "logout success");
                if (resultCode == GrCode.LOGOUT_ACCOUNT_SUCCESS) {
                    mTvUserName.setText("未登入");
                    GrAPI.getInstance().grLogin(MainActivity.this);
                    return;
                }

            }

            @Override
            public void onPayResult(int result) {
                LogUtil.d( "onPayResult:"+result);
                if (result == GrCode.PAY_GAORE_SUCCESS) {
					Toast.makeText(MainActivity.this, "儲值成功", Toast.LENGTH_SHORT).show();
                } else if (result == GrCode.PAY_GAORE_FAILED) {
					Toast.makeText(MainActivity.this, "儲值失敗", Toast.LENGTH_SHORT).show();
                }else if (result == GrCode.PAY_GAORE_CANCEL) {
                    Toast.makeText(MainActivity.this, "儲值取消", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onExit() {
                LogUtil.d( "onExit:");
                MainActivity.this.finish();
            }

            @Override
            public void onPermissionsResult(int result) {
                if (result == GrCode.GR_REQUEST_PERMISSIONS_GRANTED) {
                    //permission requset granted
                }
            }

            @Override
            public void onLoginCancel() {
                Toast.makeText(MainActivity.this, "取消登入", Toast.LENGTH_SHORT).show();
            }
        });

        GrAPI.getInstance().grOnCreate(savedInstanceState);
        // 登录
        mBtnLogin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                GrAPI.getInstance().grLogin(MainActivity.this);
            }
        });

        // 支付
        mIvPay.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                pay();
            }
        });

        // 事件上报，当前仅举例一种时机
        mBtnCreateRole.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                submitExtendData();
            }
        });

        mBtnPersonalCenter.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLogin)
                    GrAPI.getInstance().grShowPersonalCenter(MainActivity.this);
            }
        });

        // 注销
        mBtnLogout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                if (isLogin)
                    GrAPI.getInstance().grLogout();
            }
        });
    }

    // 退出
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        GrAPI.getInstance().grExit(this);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            GrAPI.getInstance().grExit(this);

        }
        return false;
    }

    @SuppressLint("NewApi")
    private void pay() {
        GRPayParams params = new GRPayParams();
        params.setBuyNum(1); // 写默认1
        params.setCoinNum(100); // 写默认100
        params.setExtension(System.currentTimeMillis() + "");
        params.setPrice((float) 4.99); // 单位是美元
        params.setProductId("com.twmobile.ljsn.499");
        params.setProductName("300魔晶");
        params.setProductDesc("購買300魔晶");
        params.setRoleId("1");
        params.setRoleLevel(10);
        params.setRoleName("測試角色名");
        params.setServerId("1");
        params.setServerName("測試");
        params.setVip("vip1");

        GrAPI.getInstance().grPay(MainActivity.this, params);
    }

    private void submitExtendData() {
        GRUserExtraData extraData = new GRUserExtraData();
        extraData.setDataType(7); // 调用时机，具体见文档
        extraData.setServerID(1 + ""); // 未获取到服务器时传0
        extraData.setServerName("伺服器名稱"); // 未获取到服务器名称时传null
        extraData.setRoleName("角色名名稱"); // 角色未获取或未创建时传null
        extraData.setRoleLevel("1"); // 当前角色等级,未获取到角色等级时传null
        extraData.setRoleID("123456789"); // 当前角色id,未获取角色id时传null
        extraData.setMoneyNum(0 + ""); // 玩家身上元宝数量，拿不到或者未获取时传0
        extraData.setRoleCreateTime(System.currentTimeMillis() / 1000);// 角色创建时间，未获取或未创建角色时传0
        extraData.setGuildId("GH10001");// 公会id，无公会或未获取时传null
        extraData.setGuildName("公會名稱");// 公会名称，无公会或未获取时传null
        extraData.setGuildLevel(100 + "");// 公会等级，无公会或未获取时传0
        extraData.setGuildLeader("公會會長名");// 公会会长名称，无公会或未获取时传null
        extraData.setPower(123123); // 角色战斗力, 不能为空，必须是数字，不能为null,若无,传0
        extraData.setProfessionid(123);// 职业ID，不能为空，必须为数字，若无，传入 0
        extraData.setProfession("職業名稱");// 职业名称，不能为空，不能为 null，若无，传入 “无”
        extraData.setGender("性别");// 角色性别，不能为空，不能为 null，可传入参数“ 男、女、无”
        extraData.setProfessionroleid(123);// 职业称号ID，不能为空，不能为 null，若无，传入 0
        extraData.setProfessionrolename("職業稱號");// 职业称号，不能为空，不能为 null，若无，传入“ 无”
        extraData.setVip(9);// 玩家VIP等级，不能为空，必须为数字,若无，传入 0
        extraData.setSignday(2);// 玩家签到天数，不能为空，必须为数字,若无，传入 0
        extraData.setAchievementId("富可敵國");// 玩家解鎖成就，不能为空，不能为 null，若无，传入“ 无”
        extraData.setGuildroleid(123);// 帮派称号 ID，帮派会长/帮主必传 1，其他可自定义，不能为空，不能为
        // null，若无，传入 0
        extraData.setGuildrolename("幫派稱號名稱");// 帮派称号名称，不能为空，不能为 null，若无，传入“无”
        Toast.makeText(MainActivity.this, extraData + "", Toast.LENGTH_SHORT).show();
        GrAPI.getInstance().grSubmitExtendData(MainActivity.this, extraData);

    }

    @Override
    protected void onStart() {
        super.onStart();
        GrAPI.getInstance().grOnStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
        GrAPI.getInstance().grOnPause(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        GrAPI.getInstance().grOnResume(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        GrAPI.getInstance().grOnNewIntent(intent);
    }

    @Override
    protected void onStop() {
        super.onStop();
        GrAPI.getInstance().grOnStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        GrAPI.getInstance().grOnDestroy();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        GrAPI.getInstance().grOnRestart();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        GrAPI.getInstance().grOnConfigurationChanged(newConfig);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        GrAPI.getInstance().grOnSaveInstanceState(outState);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        GrAPI.getInstance().grOnActivityResult(requestCode, resultCode, data, this);
    }

}
